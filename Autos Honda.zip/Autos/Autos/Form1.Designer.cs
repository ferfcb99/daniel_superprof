﻿namespace Autos
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label1 = new System.Windows.Forms.Label();
            this.txtNombreCliente = new System.Windows.Forms.TextBox();
            this.btnRecibo = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.chkPilot = new System.Windows.Forms.CheckBox();
            this.chkCRV = new System.Windows.Forms.CheckBox();
            this.chkHRV = new System.Windows.Forms.CheckBox();
            this.chkBRV = new System.Windows.Forms.CheckBox();
            this.chkOdyssey = new System.Windows.Forms.CheckBox();
            this.cmbColorCRV = new System.Windows.Forms.ComboBox();
            this.cmbTipoCRV = new System.Windows.Forms.ComboBox();
            this.cmbColorHRV = new System.Windows.Forms.ComboBox();
            this.cmbTipoHRV = new System.Windows.Forms.ComboBox();
            this.cmbTipoPilot = new System.Windows.Forms.ComboBox();
            this.cmbColorPilot = new System.Windows.Forms.ComboBox();
            this.cmbColorOdyssey = new System.Windows.Forms.ComboBox();
            this.cmbColorBRV = new System.Windows.Forms.ComboBox();
            this.cmbTipoBRV = new System.Windows.Forms.ComboBox();
            this.cmbTipoOdyssey = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(79, 55);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(117, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nombre Cliente:";
            // 
            // txtNombreCliente
            // 
            this.txtNombreCliente.Location = new System.Drawing.Point(202, 53);
            this.txtNombreCliente.Name = "txtNombreCliente";
            this.txtNombreCliente.Size = new System.Drawing.Size(213, 27);
            this.txtNombreCliente.TabIndex = 1;
            // 
            // btnRecibo
            // 
            this.btnRecibo.Location = new System.Drawing.Point(438, 36);
            this.btnRecibo.Name = "btnRecibo";
            this.btnRecibo.Size = new System.Drawing.Size(114, 60);
            this.btnRecibo.TabIndex = 2;
            this.btnRecibo.Text = "Generar Recibo";
            this.btnRecibo.UseVisualStyleBackColor = true;
            this.btnRecibo.Click += new System.EventHandler(this.btnRecibo_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 153);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(242, 150);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(684, 402);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(243, 150);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 4;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(245, 402);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(243, 150);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 5;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(412, 153);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(243, 150);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 7;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(822, 153);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(243, 150);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 8;
            this.pictureBox6.TabStop = false;
            // 
            // chkPilot
            // 
            this.chkPilot.AutoSize = true;
            this.chkPilot.Location = new System.Drawing.Point(841, 324);
            this.chkPilot.Name = "chkPilot";
            this.chkPilot.Size = new System.Drawing.Size(198, 24);
            this.chkPilot.TabIndex = 9;
            this.chkPilot.Text = "Honda Pilot ($ 1,029,900)";
            this.chkPilot.UseVisualStyleBackColor = true;
            // 
            // chkCRV
            // 
            this.chkCRV.AutoSize = true;
            this.chkCRV.Location = new System.Drawing.Point(33, 324);
            this.chkCRV.Name = "chkCRV";
            this.chkCRV.Size = new System.Drawing.Size(190, 24);
            this.chkCRV.TabIndex = 9;
            this.chkCRV.Text = "Honda CR-V ($ 634,900)";
            this.chkCRV.UseVisualStyleBackColor = true;
            // 
            // chkHRV
            // 
            this.chkHRV.AutoSize = true;
            this.chkHRV.Location = new System.Drawing.Point(438, 324);
            this.chkHRV.Name = "chkHRV";
            this.chkHRV.Size = new System.Drawing.Size(192, 24);
            this.chkHRV.TabIndex = 10;
            this.chkHRV.Text = "Honda H-RV ($ 533,900)";
            this.chkHRV.UseVisualStyleBackColor = true;
            // 
            // chkBRV
            // 
            this.chkBRV.AutoSize = true;
            this.chkBRV.Location = new System.Drawing.Point(273, 573);
            this.chkBRV.Name = "chkBRV";
            this.chkBRV.Size = new System.Drawing.Size(190, 24);
            this.chkBRV.TabIndex = 11;
            this.chkBRV.Text = "Honda BR-V ($ 449,900)";
            this.chkBRV.UseVisualStyleBackColor = true;
            // 
            // chkOdyssey
            // 
            this.chkOdyssey.AutoSize = true;
            this.chkOdyssey.Location = new System.Drawing.Point(693, 573);
            this.chkOdyssey.Name = "chkOdyssey";
            this.chkOdyssey.Size = new System.Drawing.Size(222, 24);
            this.chkOdyssey.TabIndex = 12;
            this.chkOdyssey.Text = "Honda Odyssey ($ 1,079,900)";
            this.chkOdyssey.UseVisualStyleBackColor = true;
            // 
            // cmbColorCRV
            // 
            this.cmbColorCRV.FormattingEnabled = true;
            this.cmbColorCRV.Items.AddRange(new object[] {
            "Plata",
            "Blanco",
            "Azul",
            "Rojo"});
            this.cmbColorCRV.Location = new System.Drawing.Point(264, 194);
            this.cmbColorCRV.Name = "cmbColorCRV";
            this.cmbColorCRV.Size = new System.Drawing.Size(127, 28);
            this.cmbColorCRV.TabIndex = 13;
            // 
            // cmbTipoCRV
            // 
            this.cmbTipoCRV.FormattingEnabled = true;
            this.cmbTipoCRV.Items.AddRange(new object[] {
            "CRV ARS",
            "CRV BENT",
            "CRV Test"});
            this.cmbTipoCRV.Location = new System.Drawing.Point(264, 275);
            this.cmbTipoCRV.Name = "cmbTipoCRV";
            this.cmbTipoCRV.Size = new System.Drawing.Size(127, 28);
            this.cmbTipoCRV.TabIndex = 14;
            // 
            // cmbColorHRV
            // 
            this.cmbColorHRV.FormattingEnabled = true;
            this.cmbColorHRV.Items.AddRange(new object[] {
            "Plata",
            "Blanco",
            "Azul",
            "Rojo"});
            this.cmbColorHRV.Location = new System.Drawing.Point(675, 184);
            this.cmbColorHRV.Name = "cmbColorHRV";
            this.cmbColorHRV.Size = new System.Drawing.Size(127, 28);
            this.cmbColorHRV.TabIndex = 15;
            // 
            // cmbTipoHRV
            // 
            this.cmbTipoHRV.FormattingEnabled = true;
            this.cmbTipoHRV.Items.AddRange(new object[] {
            "HRV ARS",
            "HRV BENT",
            "HRV Test"});
            this.cmbTipoHRV.Location = new System.Drawing.Point(675, 258);
            this.cmbTipoHRV.Name = "cmbTipoHRV";
            this.cmbTipoHRV.Size = new System.Drawing.Size(127, 28);
            this.cmbTipoHRV.TabIndex = 16;
            // 
            // cmbTipoPilot
            // 
            this.cmbTipoPilot.FormattingEnabled = true;
            this.cmbTipoPilot.Items.AddRange(new object[] {
            "Pilot ARS",
            "Pilot BENT",
            "Pilot Test"});
            this.cmbTipoPilot.Location = new System.Drawing.Point(1081, 258);
            this.cmbTipoPilot.Name = "cmbTipoPilot";
            this.cmbTipoPilot.Size = new System.Drawing.Size(127, 28);
            this.cmbTipoPilot.TabIndex = 17;
            // 
            // cmbColorPilot
            // 
            this.cmbColorPilot.FormattingEnabled = true;
            this.cmbColorPilot.Items.AddRange(new object[] {
            "Plata",
            "Blanco",
            "Azul",
            "Rojo"});
            this.cmbColorPilot.Location = new System.Drawing.Point(1081, 184);
            this.cmbColorPilot.Name = "cmbColorPilot";
            this.cmbColorPilot.Size = new System.Drawing.Size(127, 28);
            this.cmbColorPilot.TabIndex = 18;
            // 
            // cmbColorOdyssey
            // 
            this.cmbColorOdyssey.FormattingEnabled = true;
            this.cmbColorOdyssey.Items.AddRange(new object[] {
            "Plata",
            "Blanco",
            "Azul",
            "Rojo"});
            this.cmbColorOdyssey.Location = new System.Drawing.Point(518, 454);
            this.cmbColorOdyssey.Name = "cmbColorOdyssey";
            this.cmbColorOdyssey.Size = new System.Drawing.Size(127, 28);
            this.cmbColorOdyssey.TabIndex = 19;
            // 
            // cmbColorBRV
            // 
            this.cmbColorBRV.FormattingEnabled = true;
            this.cmbColorBRV.Items.AddRange(new object[] {
            "Plata",
            "Blanco",
            "Azul",
            "Rojo"});
            this.cmbColorBRV.Location = new System.Drawing.Point(96, 445);
            this.cmbColorBRV.Name = "cmbColorBRV";
            this.cmbColorBRV.Size = new System.Drawing.Size(127, 28);
            this.cmbColorBRV.TabIndex = 19;
            // 
            // cmbTipoBRV
            // 
            this.cmbTipoBRV.FormattingEnabled = true;
            this.cmbTipoBRV.Items.AddRange(new object[] {
            "BRV ARS",
            "BRV BENT",
            "BRV Test"});
            this.cmbTipoBRV.Location = new System.Drawing.Point(96, 524);
            this.cmbTipoBRV.Name = "cmbTipoBRV";
            this.cmbTipoBRV.Size = new System.Drawing.Size(127, 28);
            this.cmbTipoBRV.TabIndex = 20;
            // 
            // cmbTipoOdyssey
            // 
            this.cmbTipoOdyssey.FormattingEnabled = true;
            this.cmbTipoOdyssey.Items.AddRange(new object[] {
            "Odyssey ARS",
            "Odyssey BENT",
            "Odyssey Test"});
            this.cmbTipoOdyssey.Location = new System.Drawing.Point(518, 535);
            this.cmbTipoOdyssey.Name = "cmbTipoOdyssey";
            this.cmbTipoOdyssey.Size = new System.Drawing.Size(127, 28);
            this.cmbTipoOdyssey.TabIndex = 21;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(304, 240);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(39, 20);
            this.label2.TabIndex = 22;
            this.label2.Text = "Tipo";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(304, 162);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(45, 20);
            this.label3.TabIndex = 23;
            this.label3.Text = "Color";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(1119, 153);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 20);
            this.label4.TabIndex = 24;
            this.label4.Text = "Color";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(720, 153);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(45, 20);
            this.label5.TabIndex = 25;
            this.label5.Text = "Color";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(139, 413);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(45, 20);
            this.label6.TabIndex = 26;
            this.label6.Text = "Color";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(561, 413);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(45, 20);
            this.label7.TabIndex = 27;
            this.label7.Text = "Color";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(139, 491);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(39, 20);
            this.label8.TabIndex = 28;
            this.label8.Text = "Tipo";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(1125, 226);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(39, 20);
            this.label9.TabIndex = 29;
            this.label9.Text = "Tipo";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(561, 501);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(39, 20);
            this.label10.TabIndex = 30;
            this.label10.Text = "Tipo";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(726, 226);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(39, 20);
            this.label11.TabIndex = 31;
            this.label11.Text = "Tipo";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1229, 634);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cmbTipoOdyssey);
            this.Controls.Add(this.cmbTipoBRV);
            this.Controls.Add(this.cmbColorBRV);
            this.Controls.Add(this.cmbColorOdyssey);
            this.Controls.Add(this.cmbColorPilot);
            this.Controls.Add(this.cmbTipoPilot);
            this.Controls.Add(this.cmbTipoHRV);
            this.Controls.Add(this.cmbColorHRV);
            this.Controls.Add(this.cmbTipoCRV);
            this.Controls.Add(this.cmbColorCRV);
            this.Controls.Add(this.chkOdyssey);
            this.Controls.Add(this.chkBRV);
            this.Controls.Add(this.chkHRV);
            this.Controls.Add(this.chkCRV);
            this.Controls.Add(this.chkPilot);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnRecibo);
            this.Controls.Add(this.txtNombreCliente);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtNombreCliente;
        private System.Windows.Forms.Button btnRecibo;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.CheckBox chkPilot;
        private System.Windows.Forms.CheckBox chkCRV;
        private System.Windows.Forms.CheckBox chkHRV;
        private System.Windows.Forms.CheckBox chkBRV;
        private System.Windows.Forms.CheckBox chkOdyssey;
        private System.Windows.Forms.ComboBox cmbColorCRV;
        private System.Windows.Forms.ComboBox cmbTipoCRV;
        private System.Windows.Forms.ComboBox cmbColorHRV;
        private System.Windows.Forms.ComboBox cmbTipoHRV;
        private System.Windows.Forms.ComboBox cmbTipoPilot;
        private System.Windows.Forms.ComboBox cmbColorPilot;
        private System.Windows.Forms.ComboBox cmbColorOdyssey;
        private System.Windows.Forms.ComboBox cmbColorBRV;
        private System.Windows.Forms.ComboBox cmbTipoBRV;
        private System.Windows.Forms.ComboBox cmbTipoOdyssey;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
    }
}
